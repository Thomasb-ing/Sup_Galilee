# include <mpi.h>
# include <cstdlib>
# include <cmath>
# include <algorithm>
# include <iostream>
# include <cassert>
# include <stdint.h>
# include "Chronometer.hpp"

////
//// Init
////
void init( int rank, int max_rankX, int max_rankY, int* ndim_rank, int* ndim, int nfic, double* temp0, double* kdiff, double* x , double* y, double* dx )
{
  const double lx = 5.;
  const double ly = 1;

  const double mu0 =0.0000004;   // coeff diffusion beton
  const double mu1 =0.0001;      // coeff diffusion cuivre

  dx[0] = lx/(ndim[0]);
  dx[1] = ly/(ndim[1]);

  int rankPositionY = rank/max_rankX;
  int rankPositionX = (rank-rankPositionY*max_rankX);

  const double x0 = rankPositionX * lx/max_rankX ;
  const double y0 = rankPositionY * ly/max_rankY ;

  const double xinit = 2.;
  const double yinit = 0.95;

  for (int64_t i = 0; i < ndim_rank[0] ; ++i ){
     x[i] = (i-1)*dx[0] + x0;


  for (int64_t j = 0; j < ndim_rank[1] ; ++j ){
     y[j] = (j-1)*dx[1] + y0;

     int l = j*ndim_rank[0]+ i;

     temp0[l]= 280;

     if( (x[i] <= xinit or x[i] >=xinit+1) and y[j] > yinit )  {kdiff[l]=mu0;}
     else                                                      {kdiff[l]=mu1;}
  }
  }
}

////
//// mise a jour
////
void mise_a_jour( int* ndim_rank, double* temp0, double* temp1, double* bilan, const double dt, int step )
{
 double cte_rk =0.5;
 if(step==0) { cte_rk = 1;}

 for (int64_t j = 1; j < ndim_rank[1]-1 ; ++j ){ 
  for (int64_t i = 1; i < ndim_rank[0]-1 ; ++i ){ 
    
     int    l = j*ndim_rank[0]+ i;
 
     temp1[l]    = temp0[l] - dt*cte_rk*bilan[l]; 
   }
  }
}

void diffusion( int* ndim,   double* temp, double* bilan, double* dx, double* kdiff, int step  )
{
  double cte_rk =1;
  if(step==0) { cte_rk = 0;}

    for (int64_t j = 1; j < ndim[1]-1 ; ++j ) {
      for (int64_t i = 1; i < ndim[0]-1 ; ++i ) { 

         int    l = j*ndim[0]+ i;// (i  , j  )
         int    l1= l+1;         // (i+1, j  )
         int    l2= l-1;         // (i-1, j  )
         int    l3= l+ndim[0];   // (i  , j+1)
         int    l4= l-ndim[0];   // (i  , j-1)

         double mup = 0.5*( kdiff[l] + kdiff[l1]);
         double mum = 0.5*( kdiff[l] + kdiff[l2]);

         bilan[l] = bilan[l]*cte_rk- ( mup*(temp[l1]-temp[l]) - mum*(temp[l]-temp[l2]) )/(dx[0]*dx[0]);

         mup = 0.5*( kdiff[l] + kdiff[l3]);
         mum = 0.5*( kdiff[l] + kdiff[l4]);

         bilan[l] += -( mup*(temp[l3]-temp[l]) - mum*(temp[l]-temp[l4]) )/(dx[1]*dx[1]);
      }
    }
}

int main( int nargc, char* argv[])
{
  MPI_Comm globalComm;
  MPI_Request request[4];
  MPI_Status  status;

  int rank, Max_rank;
  char fileName[255];
  FILE* out;

  MPI_Init(&nargc, &argv);
  MPI_Comm_dup(MPI_COMM_WORLD, &globalComm);
  MPI_Comm_rank(globalComm, &rank);
  MPI_Comm_size(globalComm, &Max_rank);

  int dim[2]; dim[0] =500; dim[1]=500;
  int nfic     =  1;

  //if ( nargc > 1 ) dim = atoi(argv[1]);

  Chronometer chrono;
  
  sprintf(fileName, "Sortie%05d.txt", rank);
  out = fopen(fileName, "w");
 
  //
  //
  //Determination partage de la grille entre les processus MPI
  //
  //
    //Si nombre processus pair, on decoupe la grille en 2 dans la direction Y
    int Max_rankY=1;

    //on deduit le nombre de processus rÃ©partis dans la directionX
    int Max_rankX=Max_rank/Max_rankY;


    // on determine la position du rank dans cette grille (I,J) de processus    
    //
    // Exemple
    //
    //   X
    // 0   1   Y
    //
    //
    int Pos_rankY = rank/Max_rankX;
    int Pos_rankX = (rank-Pos_rankY*Max_rankX);

  fprintf(out, "Hello world from %d inside %d processus!\n", rank, Max_rank);
  fprintf(out, "rank= %d POsX= %d PosY= %d \n", rank, Pos_rankX, Pos_rankY );
  //
  //
  //Determination la taille des grilles dans les direction X ( Ndim_rank[0]) et Y ( Ndim_rank[1]) pour chacun des ranks
  //
  //
  int Ndim_rank[2];
  Ndim_rank[0] = dim[0]/Max_rankX+2*nfic;  // on suppose que tous les bloc on la meme taille
  Ndim_rank[1] = dim[1]/Max_rankY+2*nfic;  // on suppose que tous les bloc on la meme taille


  double *x,*y, *temp1, *temp0,  *bilan, *buffer, *buffer_s, *kdiff;
  x       = new double[Ndim_rank[0]];
  y       = new double[Ndim_rank[1]];

  bilan   = new double[Ndim_rank[0]*Ndim_rank[1]]; 
  temp1   = new double[Ndim_rank[0]*Ndim_rank[1]]; 
  temp0   = new double[Ndim_rank[0]*Ndim_rank[1]]; 
  kdiff   = new double[Ndim_rank[0]*Ndim_rank[1]]; 
  buffer  = new double[nfic*2*(Ndim_rank[0]+Ndim_rank[1])]; 
  buffer_s= new double[nfic*2*(Ndim_rank[0]+Ndim_rank[1])]; 
  
  for (int64_t j = 0; j < nfic*2*(Ndim_rank[0]+Ndim_rank[1])  ; ++j ){ buffer[j]=-40000; buffer_s[j]=40000;}
  
  chrono.click();
  double dx[2];

  init(  rank, Max_rankX, Max_rankY, Ndim_rank, dim, nfic,  temp0, kdiff, x, y, dx);
  fprintf(out, "dim blocX =  %d, dim blocY =  %d, dx= %f, dy= %f \n",Ndim_rank[0], Ndim_rank[1],  dx[0], dx[1] );


  for (int64_t j = 0; j < Ndim_rank[1] ; ++j ){
    for (int64_t i = 0; i < Ndim_rank[0] ; ++i ){ 

    int    l = j*Ndim_rank[0]+ i;
    fprintf(out, "Init: %f %f %f \n", x[i],y[j], temp0[l]); 
   }
    fprintf(out, "Init: \n"); 
  }


  const double dt       =0.01;  // pas de temps
  const double Tambiant =300.;  // Temperature ambiante en Kelvin
 
  //int Nitmax      =120000;
  int Nitmax      = 5000;
  int Stepmax     = 2;

  //Boucle en temps
  for (int64_t nit = 0; nit < Nitmax ; ++nit )
  { 
    //Boucle Runge-Kutta
    double *Tin;
    double *Tout;
    double *Tdiff;
    for (int64_t step = 0; step < Stepmax ; ++step )
    { 
       if(Stepmax==2){
         if(step==0) { Tin = temp0; Tout= temp1; Tdiff=temp0; }
         else        { Tin = temp0; Tout= temp0; Tdiff=temp1;}
       }
       else{ Tin = temp0; Tout= temp0; Tdiff=temp0; }


       diffusion(Ndim_rank, Tdiff, bilan,  dx, kdiff, step);
       //mise a jour point courant
       mise_a_jour(Ndim_rank, Tin, Tout, bilan,  dt, step);

      //Application Condition limite
        for (int64_t ific = 0; ific < nfic ; ++ific )
        {  
          //adiabatique en Jmin
          for (int64_t i = 0; i < Ndim_rank[0]  ; ++i )
          {  
           //Jmin
           int l0   = ific +i; 
           int l1   = Ndim_rank[0] +ific +i;

           Tout[l0] = Tout[l1];
          }
        }
        for (int64_t ific = 0; ific < nfic ; ++ific )
        {  
          //paroi isotherme en Jmax 
          for (int64_t i = 0; i < Ndim_rank[0]  ; ++i )
          {  
           int l0   = Ndim_rank[0]*(Ndim_rank[1]-nfic) +ific +i;
           Tout[l0] = Tambiant;
          }
        }


      if (Pos_rankX==0) 
      //if (rank==0) 
      { 
        for (int64_t ific = 0; ific < nfic ; ++ific )
        { 
          //paroi adiabatique en Imin
          for (int64_t j = 0; j < Ndim_rank[1]  ; ++j )
          {  
           //Imin
           int l0   = ific +j*Ndim_rank[0]; 
           int l1   = l0 +1;

           Tout[l0] = Tout[l1];
          }
        }
      }
      if (Pos_rankX==Max_rankX-1) 
      //if (rank==1) 
      { 
        for (int64_t ific = 0; ific < nfic ; ++ific )
        { 
          //paroi adiabatique en Imax 
          for (int64_t j = 0; j < Ndim_rank[1]  ; ++j )
          {  
           int l0   = ific + (j+1)*Ndim_rank[0] - 1;
           int l1   = l0 - 1;
           Tout[l0] = Tout[l1];
          }
        }
      }
      if (Max_rank!=1)

      { int shift_Imin=0;
        int shift_Imax=Ndim_rank[1];

        //nbre de raccord
        if (Max_rankX!=1)
          {  
             if (Pos_rankX==0 )
             {
               //Remplissage buffer envoi imax
               for (int64_t j = 0; j < Ndim_rank[1] ; ++j )
               {  
                int l1                    = (j+1)*Ndim_rank[0] - 2;
                buffer_s[ j + shift_Imax ]= Tout[l1];

                //fprintf(out, "buff_S Imax  %f  i= %d , shift= %d l1= %d \n", buffer_s[ j ],  j, shift_Imax, l1);
               }
             }
             else if (Pos_rankX==Max_rankX-1)
             {
               //Remplissage buffer envoi imin
               for (int64_t j = 0; j < Ndim_rank[1] ; ++j )
               {  
                int l1                    = j*Ndim_rank[0]+1;
                buffer_s[ j + shift_Imin ]= Tout[l1]; 

                //fprintf(out, "buff_S Imin  %f  i= %d , shift= %d l1= %d \n", buffer_s[ j ], j, shift_Imin, l1);
               }
             }
          }

        int rank_donor, rank_dest, shift;
        //
        //Reception non bloquante direction X
        //
           if(rank== 0 )
             { rank_donor = 1;
               shift =shift_Imax;
             }
	    else 
             { rank_donor = 0;
               shift =shift_Imin;
	     }	       
           int etiquette= rank + 10000*rank_donor;
           int size     = Ndim_rank[1];

           //fprintf(out, "Reception X:  donor=  %d, shift= %d, etiquette= %d \n",rank_donor,shift, etiquette);

           MPI_Irecv( buffer+shift, size, MPI_DOUBLE,  rank_donor,
                      etiquette,
                      globalComm,
                   &request[0]);
        //
        //Envoi  bloquant direction X
        //
           if(rank == 0) { rank_dest  = 1; shift = shift_Imax; }
           else          { rank_dest  = 0; shift = shift_Imin; }
             
           etiquette= 10000*rank + rank_dest;    //etiquette envoi    P1
           size     = Ndim_rank[1];
           MPI_Send(buffer_s+shift, size, MPI_DOUBLE,  rank_dest, etiquette, globalComm);

           //fprintf(out, "Envoi X: rank dest   %d , shift= %d, etiquette= %d  \n",rank_dest , shift, etiquette);

        //synchro MPI
         int flag=0;
         MPI_Test(&request[0], &flag, &status);
         while (!flag) { MPI_Test(&request[0], &flag, &status); } 

        //mise a jour a partir des buffer
        //
        //
        if (Max_rankX!=1) 
        { 
          if(rank == 0)
          {
            for (int64_t j = 0; j < Ndim_rank[1]  ; ++j )
            {  
             int l1   = (j+1)*Ndim_rank[0] - 1;   //imax
             Tout[l1] = buffer[j + shift_Imax ];
            }
          }
          else if(rank == 1)
          {
            for (int64_t j = 0; j < Ndim_rank[1]  ; ++j )
            {  
             int l0   =     j*Ndim_rank[0];       //imin
             Tout[l0] = buffer[j  + shift_Imin    ];
            }
          }
        }



      } // sequentiell/Parallel(Mpi=1 ou N)
     }  // Nstepmax
    }  // Nitmax


  for (int64_t i = 1; i < Ndim_rank[0]-1 ; ++i ){ 
    for (int64_t j = 1; j < Ndim_rank[1]-1 ; ++j ){ 

    int    l = j*Ndim_rank[0]+ i;
    fprintf(out, " Final %f %f %.8f \n", 0.5*(x[i]+x[i+1]),0.5*(y[j]+y[j+1]), temp0[l]); 
    //fprintf(out, " Final %f %f %.8f \n", x[i],y[j], kdiff[l]); 
   }
    fprintf(out, " Final \n"); 
  }


  double tensDt = chrono.click();
  fprintf(out, "Temps initialisation   %f  \n", tensDt);

  fclose(out);

  delete [] temp0;  delete [] temp1; delete [] bilan; delete [] x;

  MPI_Finalize();

  return EXIT_SUCCESS;
}

